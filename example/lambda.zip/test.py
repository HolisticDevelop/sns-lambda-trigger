def lambda_handler(event, context):
    print('Lambda handler executed...')
